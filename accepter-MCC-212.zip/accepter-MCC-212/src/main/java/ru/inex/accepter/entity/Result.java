package ru.inex.accepter.entity;

/**
 * Поле для ответа, результат выполнения запроса
 */
public enum Result {
    OK, FAIL
}
