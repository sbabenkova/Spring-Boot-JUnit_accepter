package ru.inex.accepter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccepterApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccepterApplication.class, args);
    }

}
