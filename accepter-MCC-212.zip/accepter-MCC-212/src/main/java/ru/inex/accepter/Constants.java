package ru.inex.accepter;

/**
 * константы
 */
public interface Constants {
    String INTERNAL_SERVER_ERROR = "Internal server error";
}
